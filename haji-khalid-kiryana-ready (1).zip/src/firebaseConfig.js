// paste firebase config here
export const firebaseConfig = {};
