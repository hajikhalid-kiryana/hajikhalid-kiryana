# Haji Khalid Kiryana — Ready Store + Admin Panel (Firebase)

## 1) One-time Firebase setup (5 minutes)
1. Go to https://console.firebase.google.com → Create project.
2. Build → Authentication → Sign-in method → **Enable Email/Password**.
3. Build → Firestore Database → **Create database** (start in production).
4. Project settings → **General** → Your apps → Web → copy SDK config.
5. Open `src/firebaseConfig.js` and paste your values.
6. Authentication → Users → Add user: **hajikhalidstore.pk@gmail.com** (set password).

## 2) Run locally
```bash
npm install
npm run dev
```
Open the URL shown (usually http://localhost:5173). Click **Login** → enter your admin email/password.

## 3) Deploy on Vercel (free)
- Create account at https://vercel.com (use the same Gmail if you want).
- New Project → Import this folder (or drag-and-drop zip).
- Framework: Vite (auto) → Build Command: `npm run build` → Output: `dist`.
- Deploy → you'll get a public link like `https://hajikhalidkiryana.vercel.app`.

## 4) Using the Admin Panel
- Click **Login** on the site → sign in with your admin email/password.
- Add products (Name, Price, Category, Image URL, Description).
- Use **Import Demo Products** to quickly add sample items.

## Notes
- Tailwind CSS is loaded via CDN in `index.html` for simplicity.
- WhatsApp order goes to: **+92 300 7490748**.
- Contact email shown: **hajikhalidstore.pk@gmail.com**.
