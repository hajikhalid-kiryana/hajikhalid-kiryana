import { useEffect, useMemo, useState } from "react";
import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged } from "firebase/auth";
import {
  getFirestore,
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
  serverTimestamp,
  query,
  orderBy,
} from "firebase/firestore";
import { firebaseConfig } from "./firebaseConfig";

// Safe initialize
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const seedProducts = [
  { id: "atta-10kg", name: "Atta 10kg", price: 0, image: "https://via.placeholder.com/600x400?text=Atta+10kg", description: "High-quality wheat flour perfect for daily rotis.", category: "Grocery" },
  { id: "cheeni-1kg", name: "Cheeni 1kg", price: 0, image: "https://via.placeholder.com/600x400?text=Cheeni+1kg", description: "Refined sugar – fresh stock.", category: "Grocery" },
  { id: "ghee-1kg", name: "Ghee 1kg", price: 0, image: "https://via.placeholder.com/600x400?text=Ghee+1kg", description: "Pure and aromatic ghee.", category: "Grocery" },
  { id: "daal-moong", name: "Daal Moong", price: 0, image: "https://via.placeholder.com/600x400?text=Daal+Moong", description: "Fresh moong daal.", category: "Pulses" },
  { id: "daal-moong-chilka", name: "Daal Moong Chilka", price: 0, image: "https://via.placeholder.com/600x400?text=Moong+Chilka", description: "Split moong with skin.", category: "Pulses" },
  { id: "daal-chana", name: "Daal Chana", price: 0, image: "https://via.placeholder.com/600x400?text=Daal+Chana", description: "Premium chana daal.", category: "Pulses" },
  { id: "kale-chane", name: "Kale Chane", price: 0, image: "https://via.placeholder.com/600x400?text=Kale+Chane", description: "High-protein black chickpeas.", category: "Pulses" },
  { id: "safaid-chane", name: "Safaid Chane", price: 0, image: "https://via.placeholder.com/600x400?text=Safaid+Chane", description: "White chickpeas.", category: "Pulses" },
  { id: "daal-mash", name: "Daal Mash", price: 0, image: "https://via.placeholder.com/600x400?text=Daal+Mash", description: "Quality mash daal.", category: "Pulses" },
  { id: "daal-mash-chilka", name: "Daal Mash Chilka", price: 0, image: "https://via.placeholder.com/600x400?text=Mash+Chilka", description: "Split mash with skin.", category: "Pulses" },
  { id: "saaf-mash-safaid", name: "Saaf Daal Mash Safaid", price: 0, image: "https://via.placeholder.com/600x400?text=Mash+Safaid", description: "Cleaned white mash.", category: "Pulses" },
  { id: "saaf-daal-masoor", name: "Saaf Daal Masoor", price: 0, image: "https://via.placeholder.com/600x400?text=Saaf+Masoor", description: "Cleaned masoor daal.", category: "Pulses" },
  { id: "daal-masoor", name: "Daal Masoor", price: 0, image: "https://via.placeholder.com/600x400?text=Daal+Masoor", description: "Everyday masoor daal.", category: "Pulses" },
  { id: "salad", name: "Salad", price: 0, image: "https://via.placeholder.com/600x400?text=Salad", description: "Fresh salad items.", category: "Grocery" },
];

function formatPKR(n) {
  try { return `Rs. ${Number(n || 0).toLocaleString("en-PK")}`; } catch { return `Rs. ${n}`; }
}

function Header({ route, setRoute, cartCount, user }) {
  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <button onClick={() => setRoute("home")} className="text-2xl font-extrabold text-green-700">
          Haji Khalid <span className="text-green-900">Kiryana</span>
        </button>
        <nav className="flex items-center gap-3 sm:gap-6 text-sm sm:text-base">
          <button onClick={() => setRoute("products")} className={navClass(route === "products")}>Products</button>
          <button onClick={() => setRoute("contact")} className={navClass(route === "contact")}>Contact</button>
          <button onClick={() => setRoute("cart")} className="relative px-3 py-1 rounded-full bg-green-600 text-white">
            Cart{cartCount ? <span className="ml-2 bg-white text-green-700 px-2 py-0.5 rounded-full text-xs">{cartCount}</span> : null}
          </button>
          <button onClick={() => setRoute("admin")} className={navClass(route === "admin")}>{user ? "Admin" : "Login"}</button>
        </nav>
      </div>
    </header>
  );
}

function navClass(active) {
  return `px-3 py-1 rounded-full ${active ? "bg-green-100 text-green-700" : "hover:bg-gray-100"}`;
}

function Hero({ setRoute }) {
  return (
    <section className="bg-gradient-to-br from-green-50 to-white">
      <div className="max-w-6xl mx-auto px-4 py-12 sm:py-16 grid sm:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl sm:text-5xl font-black text-green-700 leading-tight">Fresh Grocery at Your Doorstep</h1>
          <p className="mt-3 text-gray-600">Nawab Chowk, Gujranwala • Cash on Delivery • WhatsApp Orders</p>
          <div className="mt-6 flex gap-3">
            <button onClick={() => setRoute("products")} className="px-5 py-3 rounded-2xl bg-green-600 text-white shadow hover:bg-green-700">Shop Now</button>
            <a href="https://wa.me/923007490748" target="_blank" rel="noreferrer" className="px-5 py-3 rounded-2xl border border-green-600 text-green-700 hover:bg-green-50">WhatsApp</a>
          </div>
        </div>
        <div className="rounded-3xl overflow-hidden shadow-xl border">
          <img src="https://via.placeholder.com/900x600?text=Haji+Khalid+Kiryana" alt="Haji Khalid Kiryana" className="w-full h-full object-cover"/>
        </div>
      </div>
    </section>
  );
}

function ProductGrid({ products, addToCart }) {
  if (!products.length) {
    return <div className="bg-white p-6 rounded-2xl border text-center">No products yet. Please check back soon.</div>;
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((p) => (
        <div key={p.id} className="bg-white rounded-2xl shadow border overflow-hidden flex flex-col">
          <img src={p.image} alt={p.name} className="w-full h-48 object-cover" />
          <div className="p-4 flex-1 flex flex-col">
            <div className="text-xs text-gray-500">{p.category || "General"}</div>
            <h3 className="font-semibold text-lg">{p.name}</h3>
            <p className="text-sm text-gray-600 mt-1 line-clamp-2">{p.description}</p>
            <div className="mt-4 flex items-center justify-between">
              <span className={`font-bold ${p.price ? "text-green-700" : "text-amber-600"}`}>
                {p.price ? formatPKR(p.price) : "Set price"}
              </span>
              {p.price ? (
                <button onClick={() => addToCart(p.id)} className="px-3 py-2 rounded-xl bg-green-600 text-white hover:bg-green-700">Add to Cart</button>
              ) : (
                <a href={`https://wa.me/923007490748?text=${encodeURIComponent("Price for " + p.name + "?")}`} target="_blank" rel="noreferrer" className="px-3 py-2 rounded-xl border border-amber-600 text-amber-700 hover:bg-amber-50">Ask Price</a>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function CartPage({ cart, setCart, products, setRoute }) {
  const items = cart.map((it) => ({ ...it, product: products.find((p) => p.id === it.id) })).filter((x) => x.product);
  const subTotal = items.reduce((s, it) => s + (Number(it.product.price)||0) * it.qty, 0);
  const updateQty = (id, qty) => { if (qty < 1) return; setCart((c) => c.map((i) => (i.id === id ? { ...i, qty } : i))); };
  const removeItem = (id) => setCart((c) => c.filter((i) => i.id !== id));
  return (
    <section className="max-w-6xl mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-6">Your Cart</h2>
      {items.length === 0 ? (
        <div className="bg-white p-6 rounded-2xl border text-center">
          <p>Your cart is empty.</p>
          <button onClick={() => setRoute("products")} className="mt-4 px-4 py-2 rounded-xl bg-green-600 text-white">Go to Products</button>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {items.map((it) => (
              <div key={it.id} className="bg-white p-4 rounded-2xl border flex items-center gap-4">
                <img src={it.product.image} className="w-20 h-20 object-cover rounded-xl border"/>
                <div className="flex-1">
                  <div className="font-medium">{it.product.name}</div>
                  <div className="text-sm text-gray-600">{formatPKR(it.product.price)} each</div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQty(it.id, it.qty - 1)} className="px-3 py-1 rounded-lg border">-</button>
                  <span className="w-8 text-center">{it.qty}</span>
                  <button onClick={() => updateQty(it.id, it.qty + 1)} className="px-3 py-1 rounded-lg border">+</button>
                </div>
                <div className="w-24 text-right font-semibold">{formatPKR((Number(it.product.price)||0) * it.qty)}</div>
                <button onClick={() => removeItem(it.id)} className="ml-2 text-red-600 hover:underline">Remove</button>
              </div>
            ))}
          </div>
          <div className="bg-white p-6 rounded-2xl border h-max">
            <div className="flex justify-between mb-2"><span>Subtotal</span><span>{formatPKR(subTotal)}</span></div>
            <div className="flex justify-between text-sm text-gray-600 mb-4"><span>Delivery</span><span>Calculated on WhatsApp</span></div>
            <button onClick={() => setRoute("checkout")} className="w-full px-4 py-3 rounded-2xl bg-green-600 text-white">Proceed to Checkout</button>
          </div>
        </div>
      )}
    </section>
  );
}

function CheckoutPage({ cart, clearCart, products }) {
  const items = cart.map((it) => ({ ...it, product: products.find((p) => p.id === it.id) })).filter((x) => x.product);
  const total = items.reduce((s, it) => s + (Number(it.product.price)||0) * it.qty, 0);
  const [form, setForm] = useState({ name: "", phone: "", address: "", city: "Gujranwala", payment: "COD" });

  const message = useMemo(() => {
    const lines = [
      "New Order - Haji Khalid Kiryana",
      "",
      "Items:",
      ...items.map((it) => `• ${it.product.name} x ${it.qty} = ${formatPKR((Number(it.product.price)||0) * it.qty)}`),
      "",
      `Total: ${formatPKR(total)}`,
      "",
      "Customer:",
      `Name: ${form.name}`,
      `Phone: ${form.phone}`,
      `City: ${form.city}`,
      `Address: ${form.address}`,
      `Payment: ${form.payment}`,
    ];
    return lines.join("\n");
  }, [items, total, form]);

  const disabled = !form.name || !form.phone || !form.address || items.length === 0;

  return (
    <section className="max-w-4xl mx-auto px-4 py-8 grid lg:grid-cols-2 gap-6">
      <div className="bg-white p-6 rounded-2xl border">
        <h3 className="text-xl font-semibold mb-4">Delivery Details</h3>
        <div className="space-y-3">
          <input className="w-full border rounded-xl px-3 py-2" placeholder="Full Name" value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})}/>
          <input className="w-full border rounded-xl px-3 py-2" placeholder="Phone (WhatsApp)" value={form.phone} onChange={(e)=>setForm({...form,phone:e.target.value})}/>
          <input className="w-full border rounded-xl px-3 py-2" placeholder="City" value={form.city} onChange={(e)=>setForm({...form,city:e.target.value})}/>
          <textarea className="w-full border rounded-xl px-3 py-2" placeholder="Complete Address" rows={4} value={form.address} onChange={(e)=>setForm({...form,address:e.target.value})}/>
          <div className="flex items-center gap-3">
            <label className="font-medium">Payment:</label>
            <select className="border rounded-xl px-3 py-2" value={form.payment} onChange={(e)=>setForm({...form,payment:e.target.value})}>
              <option value="COD">Cash on Delivery (COD)</option>
              <option value="Bank">Bank Transfer</option>
              <option value="Easypaisa">Easypaisa</option>
              <option value="JazzCash">JazzCash</option>
            </select>
          </div>
        </div>
      </div>
      <div className="bg-white p-6 rounded-2xl border h-max">
        <h3 className="text-xl font-semibold mb-4">Order Summary</h3>
        <div className="space-y-2">
          {items.map((it) => (
            <div key={it.id} className="flex justify-between text-sm">
              <div>{it.product.name} × {it.qty}</div>
              <div>{formatPKR((Number(it.product.price)||0) * it.qty)}</div>
            </div>
          ))}
        </div>
        <div className="flex justify-between font-semibold mt-4 border-t pt-3">
          <span>Total</span>
          <span>{formatPKR(total)}</span>
        </div>
        <a
          href={`https://wa.me/923007490748?text=${encodeURIComponent(message)}`}
          target="_blank"
          rel="noreferrer"
          className={`mt-6 inline-flex items-center justify-center w-full px-4 py-3 rounded-2xl ${disabled ? "bg-gray-300 cursor-not-allowed" : "bg-green-600 hover:bg-green-700"} text-white`}
          onClick={() => { if (!disabled) clearCart(); }}
        >
          Place Order on WhatsApp
        </a>
        <p className="text-xs text-gray-500 mt-2">Note: Delivery charges (if any) will be confirmed on WhatsApp.</p>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section className="max-w-3xl mx-auto px-4 py-10">
      <div className="bg-white p-6 rounded-2xl border">
        <h2 className="text-2xl font-bold mb-2">Contact Us</h2>
        <p className="text-gray-600">Nawab Chowk, Gujranwala, Punjab, Pakistan</p>
        <div className="mt-4 space-y-2">
          <a className="block" href="tel:+923007490748">📞 0300-7490748</a>
          <a className="block" href="https://wa.me/923007490748" target="_blank" rel="noreferrer">💬 WhatsApp</a>
          <a className="block" href="mailto:hajikhalidstore.pk@gmail.com">✉️ hajikhalidstore.pk@gmail.com</a>
        </div>
        <p className="mt-4 text-sm text-gray-600">Working hours: 9:00 AM – 10:00 PM (Mon–Sun)</p>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="mt-12 border-t">
      <div className="max-w-6xl mx-auto px-4 py-8 text-center text-sm text-gray-600">
        © {new Date().getFullYear()} Haji Khalid Kiryana — All rights reserved.
      </div>
    </footer>
  );
}

function Admin({ user, setRoute }) {
  return user ? <AdminPanel setRoute={setRoute} /> : <LoginForm />;
}

function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");

  const onLogin = async (e) => {
    e.preventDefault();
    setErr("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (e) {
      setErr(e.message || "Login failed");
    }
  };

  return (
    <section className="max-w-md mx-auto px-4 py-10">
      <div className="bg-white p-6 rounded-2xl border">
        <h2 className="text-2xl font-bold mb-2">Admin Login</h2>
        <p className="text-sm text-gray-600 mb-4">Use your store admin email/password (e.g. hajikhalidstore.pk@gmail.com).</p>
        <form onSubmit={onLogin} className="space-y-3">
          <input className="w-full border rounded-xl px-3 py-2" placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
          <input className="w-full border rounded-xl px-3 py-2" placeholder="Password" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
          {err && <div className="text-sm text-red-600">{err}</div>}
          <button className="w-full px-4 py-2 rounded-2xl bg-green-600 text-white">Login</button>
        </form>
        <p className="text-xs text-gray-500 mt-4">Tip: If login fails, ensure Firebase Auth (Email/Password) is enabled and config keys are correct.</p>
      </div>
    </section>
  );
}

function AdminPanel({ setRoute }) {
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ id: "", name: "", price: 0, image: "", description: "", category: "Grocery" });

  useEffect(() => {
    const q = query(collection(db, "products"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      const items = [];
      snap.forEach((d) => items.push({ uid: d.id, ...d.data() }));
      setList(items);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const resetForm = () => setForm({ id: "", name: "", price: 0, image: "", description: "", category: "Grocery" });

  const addOrUpdate = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (form.uid) {
        await updateDoc(doc(db, "products", form.uid), {
          id: form.id || form.name.toLowerCase().replace(/\s+/g, "-"),
          name: form.name,
          price: Number(form.price)||0,
          image: form.image,
          description: form.description,
          category: form.category,
          updatedAt: serverTimestamp(),
        });
      } else {
        await addDoc(collection(db, "products"), {
          id: form.id || form.name.toLowerCase().replace(/\s+/g, "-"),
          name: form.name,
          price: Number(form.price)||0,
          image: form.image || "https://via.placeholder.com/600x400?text=" + encodeURIComponent(form.name),
          description: form.description,
          category: form.category,
          createdAt: serverTimestamp(),
        });
      }
      resetForm();
    } catch (e) {
      alert(e.message || "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  const edit = (item) => setForm(item);
  const remove = async (uid) => {
    if (!confirm("Delete this product?")) return;
    try {
      await deleteDoc(doc(db, "products", uid));
    } catch (e) {
      alert(e.message || "Failed to delete");
    }
  };

  const seed = async () => {
    if (!confirm("Import demo products?")) return;
    try {
      for (const p of seedProducts) {
        await addDoc(collection(db, "products"), { ...p, createdAt: serverTimestamp() });
      }
    } catch (e) {
      alert(e.message || "Seed failed");
    }
  };

  return (
    <section className="max-w-6xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Admin Panel</h2>
        <div className="flex items-center gap-2">
          <button onClick={() => seed()} className="px-3 py-2 rounded-xl border">Import Demo Products</button>
          <button onClick={async ()=>{await signOut(auth); location.reload();}} className="px-3 py-2 rounded-xl bg-red-600 text-white">Logout</button>
        </div>
      </div>

      <form onSubmit={addOrUpdate} className="bg-white p-4 rounded-2xl border grid md:grid-cols-2 gap-4 mb-8">
        <div>
          <label className="text-sm text-gray-600">Name</label>
          <input className="w-full border rounded-xl px-3 py-2" value={form.name} onChange={(e)=>setForm({...form,name:e.target.value})} required/>
        </div>
        <div>
          <label className="text-sm text-gray-600">Price (PKR)</label>
          <input type="number" min={0} className="w-full border rounded-xl px-3 py-2" value={form.price} onChange={(e)=>setForm({...form,price:e.target.value})}/>
        </div>
        <div>
          <label className="text-sm text-gray-600">Category</label>
          <input className="w-full border rounded-xl px-3 py-2" value={form.category} onChange={(e)=>setForm({...form,category:e.target.value})}/>
        </div>
        <div>
          <label className="text-sm text-gray-600">Image URL</label>
          <input className="w-full border rounded-xl px-3 py-2" value={form.image} onChange={(e)=>setForm({...form,image:e.target.value})}/>
        </div>
        <div className="md:col-span-2">
          <label className="text-sm text-gray-600">Description</label>
          <textarea rows={3} className="w-full border rounded-xl px-3 py-2" value={form.description} onChange={(e)=>setForm({...form,description:e.target.value})}/>
        </div>
        <div className="md:col-span-2 flex gap-3">
          <button disabled={saving} className={`px-4 py-2 rounded-2xl ${saving?"bg-gray-300":"bg-green-600 hover:bg-green-700"} text-white`}>{form.uid?"Update":"Add"} Product</button>
          <button type="button" onClick={() => setForm({ id: "", name: "", price: 0, image: "", description: "", category: "Grocery" })} className="px-4 py-2 rounded-2xl border">Clear</button>
        </div>
      </form>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <div className="col-span-full text-center text-gray-600">Loading…</div>
        ) : list.length === 0 ? (
          <div className="col-span-full text-center text-gray-600">No products yet.</div>
        ) : (
          list.map((p) => (
            <div key={p.uid} className="bg-white p-4 rounded-2xl border">
              <img src={p.image} alt={p.name} className="w-full h-40 object-cover rounded-xl border"/>
              <div className="mt-3 text-xs text-gray-500">{p.category}</div>
              <div className="font-semibold">{p.name}</div>
              <div className="text-green-700 font-bold">{p.price?formatPKR(p.price):"Set price"}</div>
              <div className="mt-3 flex gap-2">
                <button onClick={()=>setForm(p)} className="px-3 py-1 rounded-xl border">Edit</button>
                <button onClick={()=>remove(p.uid)} className="px-3 py-1 rounded-2xl bg-red-600 text-white">Delete</button>
              </div>
            </div>
          ))
        )}
      </div>
    </section>
  );
}

export default function App() {
  const [route, setRoute] = useState("home");
  const [cart, setCart] = useState([]);
  const [products, setProducts] = useState([]);
  const [user, setUser] = useState(null);

  useEffect(() => { const unsub = onAuthStateChanged(auth, (u) => setUser(u)); return () => unsub(); }, []);

  useEffect(() => {
    const q = query(collection(db, "products"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      const arr = []; snap.forEach((d) => arr.push(d.data()));
      setProducts(arr.length ? arr : seedProducts);
    });
    return () => unsub();
  }, []);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const addToCart = (id) => {
    const prod = products.find((p) => p.id === id);
    if (!prod || !Number(prod.price)) return;
    setCart((c) => {
      const exists = c.find((i) => i.id === id);
      if (exists) return c.map((i) => (i.id === id ? { ...i, qty: i.qty + 1 } : i));
      return [...c, { id, qty: 1 }];
    });
  };
  const clearCart = () => setCart([]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header route={route} setRoute={setRoute} cartCount={cartCount} user={user} />
      {route === "home" && (<>
        <Hero setRoute={setRoute} />
        <section className="max-w-6xl mx-auto px-4 py-10">
          <h2 className="text-2xl font-bold mb-6">Popular Products</h2>
          <ProductGrid products={products.slice(0, 6)} addToCart={addToCart} />
        </section>
      </>)}
      {route === "products" && (
        <section className="max-w-6xl mx-auto px-4 py-10">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">All Products</h2>
            <div className="text-sm text-gray-600">Managed via Admin Panel</div>
          </div>
          <ProductGrid products={products} addToCart={addToCart} />
        </section>
      )}
      {route === "cart" && (<CartPage cart={cart} setCart={setCart} products={products} setRoute={setRoute} />)}
      {route === "checkout" && (<CheckoutPage cart={cart} clearCart={clearCart} products={products} />)}
      {route === "contact" && <Contact />}
      {route === "admin" && <Admin user={user} setRoute={setRoute} />}
      <a href="https://wa.me/923007490748" target="_blank" rel="noreferrer" className="fixed bottom-5 right-5 shadow-lg rounded-full px-4 py-3 bg-green-600 text-white">WhatsApp Us</a>
      <Footer />
    </div>
  );
}
